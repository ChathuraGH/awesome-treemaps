Treemap-js
==========

jQuery plugin for drawing squarified treemaps
